/*
*********************************************************************************************************
*                                        Periodic TASK   
*********************************************************************************************************
*/

void  PeriodicTask (void *pdata)
{
    INT8U  x;
    TASK_EXTRA_DATA *MyPtr; 
    char s[34];
    char p[34];
    INT8U i;
    INT32U TaskTime;
    
    pdata=pdata;
    MyPtr = OSTCBCur->OSTCBExtPtr;
    x =0;

    MyPtr->Deadline = MyStartTime + MyPtr->Period;    
    MyPtr->RemainTime = MyPtr->ExecutionTime;
    for (;;) 
    {
	x++;
	sprintf(s, "%4d",x); 
        PC_DispStr(75, 10 + OSPrioCur - PERIODIC_TASK_START_PRIO, s, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
	sprintf(s, "%10d ",OSTimeGet() ); 
        PC_DispStr(15, 10 + OSPrioCur - PERIODIC_TASK_START_PRIO, s, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY); 
	sprintf(s, "%10d ", MyPtr->Deadline); 
        PC_DispStr(39, 10 + OSPrioCur - PERIODIC_TASK_START_PRIO, s, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
	while(1)
	{
	    if(MyPtr->RemainTime <=0) {break;}
	}
          
	MyPtr->Deadline = MyPtr->Deadline + MyPtr->Period;
	MyPtr->RemainTime = MyPtr->ExecutionTime;

	sprintf(s, "%10d ",OSTimeGet() ); 
        PC_DispStr(27, 10 + OSPrioCur - PERIODIC_TASK_START_PRIO, s, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);

        if(MyPtr->Deadline - MyPtr->Period > OSTimeGet() ) {OSTimeDly(MyPtr->Deadline - MyPtr->Period - OSTimeGet());}
    }
}

/*******************************************************************************************************/