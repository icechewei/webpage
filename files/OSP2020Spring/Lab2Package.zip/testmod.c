#include <linux/init.h>
#include <linux/module.h>
MODULE_LICENSE("License for you");

static int mymodule_init(void)
{
	printk("Instert MyModule to the Linux Kernel!\n");
	return 0;
}

static void mymodule_exit(void)
{
	printk("MyModule Unloaded!\n");
}

module_init(mymodule_init);
module_exit(mymodule_exit);
